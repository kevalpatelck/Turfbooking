import React from 'react';

function Settings() {
  return (
    <div>
      <h1>Settings</h1>
      <p>Modify user settings here.</p>
    </div>
  );
}

export default Settings;
