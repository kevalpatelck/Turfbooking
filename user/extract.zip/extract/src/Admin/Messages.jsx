import React from 'react';

function Messages() {
  return (
    <div>
      <h1>Messages</h1>
      <p>Check user messages here.</p>
    </div>
  );
}

export default Messages;
