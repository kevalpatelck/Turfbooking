import React from 'react';
import AddTurfForm from './AddTurfForm';

function Analytics() {
  return (
    <div>
      <h1>Add New Turf</h1>
    </div>
  );
}

export default Analytics;
