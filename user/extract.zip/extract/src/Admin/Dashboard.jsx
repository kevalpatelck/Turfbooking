import React from 'react';

function Dashboard() {
  return (
    <div>
      <h1>Dashboard</h1>
      <p>View all essential data here.</p>
    </div>
  );
}

export default Dashboard;
